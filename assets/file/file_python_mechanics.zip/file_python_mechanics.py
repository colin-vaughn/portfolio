import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, RadioButtons

class MaterialMechanicsDashboard:
    def __init__(self):
        # --- PRESETS ---
        self.materials = {
            "A36 Steel":     (200, 250, 400, 0.20, 0.25),
            "Al 6061-T6":    (68.9, 276, 310, 0.12, 0.17),
            "Ti-6Al-4V":     (113, 880, 950, 0.15, 0.14),
            "Custom":        (200, 250, 400, 0.20, 0.25)
        }
        
        # Shapes: (Area in mm^2) based on a 50mm characteristic dimension
        self.shapes = {
            "Circle (d=50)": np.pi * (25**2),
            "Square (50x50)": 50 * 50,
            "I-Beam (S-Flange)": 1200 # Simplified area for a small section
        }
        
        # --- INITIAL SETUP ---
        self.fig = plt.figure(figsize=(15, 10), facecolor='#121212') 
        self.fig.suptitle("Structural Mechanics Studio v4.3 | Cross-Section Analysis", color='white', fontsize=16, fontweight='bold')
        
        gs = self.fig.add_gridspec(4, 4, width_ratios=[1.2, 2, 2, 1.2], height_ratios=[4, 1.5, 1.5, 1], hspace=0.6, wspace=0.4)
        
        self.ax_plot = self.fig.add_subplot(gs[0, :])
        self.ax_res = self.fig.add_subplot(gs[1, 1])
        self.ax_tough = self.fig.add_subplot(gs[1, 2])
        self.axes_to_format = [self.ax_plot, self.ax_res, self.ax_tough]

        self._setup_axes_formatting()

        # --- SLIDERS ---
        labels = ['E [GPa]', r'$\sigma_y$ [MPa]', r'$\sigma_u$ [MPa]', 'n', r'$\epsilon_f$']
        ranges = [(10, 500), (50, 1500), (100, 2000), (0.01, 0.5), (0.01, 0.6)]
        init_vals = self.materials["A36 Steel"]

        self.sliders = []
        slider_locs = [(1, 0), (2, 0), (1, 3), (2, 3), (3, 1)] 
        for i, (label, s_range, loc) in enumerate(zip(labels, ranges, slider_locs)):
            ax = self.fig.add_subplot(gs[loc[0], loc[1]])
            s = Slider(ax, label, s_range[0], s_range[1], valinit=init_vals[i], color='#3498db')
            s.label.set_color('white')
            s.valtext.set_color('white')
            s.on_changed(self.update)
            self.sliders.append(s)

        # --- RADIO BUTTONS (MODES, PRESETS, SHAPES) ---
        # Loading Mode
        self.radio_mode = self._create_radio(gs[2, 1], "Mode", ('Tension', 'Compression', 'Shear'))
        
        # Materials
        self.radio_mat = self._create_radio(gs[1, 0], "Material", list(self.materials.keys()))
        self.radio_mat.on_clicked(self.update_preset)
        
        # Shapes (THE NEW ADDITION)
        self.radio_shape = self._create_radio(gs[2, 2], "Cross-Section Shape", list(self.shapes.keys()))

        self.update(None)
        plt.show()

    def _create_radio(self, gs_loc, title, labels):
        ax = self.fig.add_subplot(gs_loc)
        ax.set_facecolor('#121212')
        ax.set_title(title, color='#3498db', fontsize=10, fontweight='bold')
        radio = RadioButtons(ax, labels, activecolor='#2ecc71')
        for l in radio.labels: l.set_color('white')
        radio.on_clicked(self.update)
        return radio

    def _setup_axes_formatting(self):
        for ax in self.axes_to_format:
            ax.set_facecolor('#1E1E1E')
            ax.tick_params(colors='white', which='both', labelsize=9)
            ax.grid(True, linestyle='--', color='#444444', alpha=0.3)
            for spine in ax.spines.values(): spine.set_edgecolor('#555555')
        self.ax_plot.set_xlabel(r"Strain ($\epsilon$)", color='white')
        self.ax_plot.set_ylabel(r"Stress ($\sigma$) [MPa]", color='white')

    def update_preset(self, label):
        if label == "Custom": return 
        vals = self.materials[label]
        for s, v in zip(self.sliders, vals): s.set_val(v)
        self.update(None)

    def update(self, val):
        E_gpa, sy, su, n, ef = [s.val for s in self.sliders]
        mode = self.radio_mode.value_selected
        area = self.shapes[self.radio_shape.value_selected]
        
        E = max(E_gpa * 1000, 1e-6)
        ey = sy / E
        
        # Elastic
        se = np.linspace(0, ey, 50)
        ste = E * se
        # Plastic
        sp = np.linspace(ey, max(ef, ey+0.01), 150)
        stp = sy + (su - sy) * ((sp - ey) / (max(ef, ey+0.01) - ey))**max(n, 0.01)
        
        # Calculate Max Load (P = sigma * A) - converted to kN
        max_load = (max(stp) * area) / 1000 

        self.ax_plot.cla()
        self.ax_res.cla()
        self.ax_tough.cla()
        self._setup_axes_formatting()

        # Visual Fills
        self.ax_plot.fill_between(se, ste, color='#3498db', alpha=0.2, label='Elastic (Resilience)')
        self.ax_plot.fill_between(sp, stp, color='#e67e22', alpha=0.2, label='Plastic (Toughness)')
        self.ax_plot.plot(np.concatenate([se, sp]), np.concatenate([ste, stp]), color='#2ecc71', lw=3)
        
        # Dynamic Title with Cross-Section Info
        self.ax_plot.set_title(f"Max Structural Load Capacity: {max_load:.2f} kN", color='#2ecc71', fontsize=14, pad=20)
        
        self.ax_plot.legend(facecolor='#1E1E1E', labelcolor='white')
        self.ax_plot.set_ylim(0, max(stp) * 1.4)

        # Update Energy Bars
        trap = np.trapezoid if hasattr(np, 'trapezoid') else np.trapz
        res, tough = trap(ste, se), trap(stp, sp) + trap(ste, se)
        self.ax_res.bar(["Resilience"], [res], color='#3498db')
        self.ax_tough.bar(["Toughness"], [tough], color='#e67e22')

        self.fig.canvas.draw_idle()

MaterialMechanicsDashboard()