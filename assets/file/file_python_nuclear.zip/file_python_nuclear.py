
"""
Name: Colin Vaughn
Class: NE 3301
Project: Modeling Rate of Decay of Calcium-47 over 10 Half-Lives 
"""

#IMPORTING LIBRARIES
import os
import numpy as np
import matplotlib.pyplot as plt

#DEFINING CONSTANTS
N_A = 6.022e23 #avogadro's number
#mass
initial_mass = 40.0 #initial mass of Ca-47
atomic_mass = 46.95 #atomic mass of Ca-47

#half-life
half_life_Ca = 4.536 #half life of Ca-47
half_life_Sc = 3.349 #half life of Sc-47

#CALCULATING CONSTANTS
#decay constant from ln2/t_1/2
decay_constant_Ca = np.log(2) / half_life_Ca #calculate decay constant of Ca-47 
decay_constant_Sc = np.log(2) / half_life_Sc #calculate decay constant of Sc-47
decay_constant_Ti = 0 #Ti-47 is stable, so the decay constant = 0

#initial atom quanitity 
initial_atoms_Ca = (initial_mass / atomic_mass) * N_A #calculate the initial number of atoms of Ca-47 from mass
initial_atoms_Sc = 0 #per assignment directions, the Ca-47 source is pure and includes no Sc-47 initially
initial_atoms_Ti = 0 #per assignment directions, the Ca-47 source is pure and includes no Ti-47 initially

#CONFIGURING TIME ARRAY
time_max = 10 * half_life_Ca #changes time increments on graph - 10 was a good balance to show depletion
steps = 100 #number of data points to be plotted in the graph - 100 was plenty of points to make it smooth

time = np.linspace(0, time_max, steps)

#DEFINING EQUATIONS
#decay equation for Ca-47 from equation 5.57
N_Ca = initial_atoms_Ca * np.exp(-decay_constant_Ca * time) 

#decay equation for Sc-47 from equation 5.58
N_Sc = ( (initial_atoms_Sc * np.exp(-decay_constant_Sc * time)) + #this term disappears because N_0(Sc) = 0
    ((initial_atoms_Ca * decay_constant_Ca) / (decay_constant_Sc - decay_constant_Ca)) * 
        ((np.exp(-decay_constant_Ca * time))-(np.exp(-decay_constant_Sc * time))) )

#decay equation for Ti-47 from equation 5.59 (stable, decay_constant_Ti = 0)
N_Ti = ( (initial_atoms_Ti) + #this term disappears because N_0(Ti) = 0
    (initial_atoms_Sc * (1 - np.exp(-decay_constant_Ti * time))) + #this term disappears because N_0(Sc) = 0
    ((initial_atoms_Ca / (decay_constant_Sc - decay_constant_Ca)) * 
        ((decay_constant_Sc * (1 - np.exp(-decay_constant_Ca * time))) - 
        (decay_constant_Ca * (1 - np.exp(-decay_constant_Sc * time))))) )

#PLOT RESULTS
#define line colors and labels
plt.plot (time, N_Ca , color = 'mediumblue', label = 'Ca-47 (Parent Nuclide)')
plt.plot (time, N_Sc , color = 'cornflowerblue', label = 'Sc-47 (Daughter Nuclide)')
plt.plot (time, N_Ti , color = 'lightblue', label = 'Ti-47 (Stable Granddaughter)')

#define titles and axis labels
plt.title ('Decay of Calcium-47 through 10 Half-Lives')
plt.ylabel ('Quantity of Nuclide (in atoms)')
plt.xlabel ('Time Passed (in days)')

#define legend
plt.legend ()

plt.savefig('C:/Users/colin/OneDrive/Documents/College/26 Spring/NE 3301 - Nuclear Engineering I/Vaughn_NE3301_HW10_Plot.png')
plt.show ()

